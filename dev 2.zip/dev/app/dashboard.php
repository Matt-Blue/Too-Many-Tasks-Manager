<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class dashboard extends Model
{

}
