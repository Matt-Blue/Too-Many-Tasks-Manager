<?php $__env->startSection('content'); ?>

<?php 
    foreach($tasks as $task){
        $task_id = $task->id;
        $task_name = $task->task_name;
        $priority = $task->priority;
        $date = $task->date;
        $time = $task->time;
    }
?>
<div class="col-xs-6 col-xs-offset-3">
    <!-- EDIT TASK FORM -->
    <?php echo Form::open(['route' => 'edit_task']); ?>


    <div class="form-group">
        <?php echo Form::label('task_name', 'Task Name'); ?>

        <?php echo Form::text('task_name', $task_name, ['class' => 'form-control']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::label('priority', 'Priority'); ?>

        <?php echo Form::select('priority', [0, 1, 2, 3, 4, 5], $priority); ?>

    </div>

    <div class="form-group">
        <?php echo Form::label('date', 'Due Date'); ?>

        <?php echo Form::date('date', $date, ['class' => 'form-control']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::label('time', 'Time'); ?>

        <?php echo Form::time('time', $time, ['class' => 'form-control']); ?>

    </div>

    <?php echo Form::hidden('task_id', $task_id); ?>


    <?php echo Form::submit('Update', ['class' => 'btn btn-primary pull-right']); ?>


    <?php echo Form::close(); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>