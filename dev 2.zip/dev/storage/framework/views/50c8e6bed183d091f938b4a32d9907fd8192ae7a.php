<?php $__env->startSection('content'); ?>
    <?php if(Route::has('login')): ?>
        <div class="top-right links">
            
        </div>
    <?php endif; ?>

    <div class="content">
        <center>
            <h1>Too Many Tasks Manager</h1><br>
            <?php if(Auth::check()): ?>
                <button class="btn btn-default"><a href="<?php echo e(url('/home')); ?>" id="black"><?php echo e(Auth::user()->name); ?>'s Dashboard</a></button>
            <?php endif; ?>        
        </center>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>