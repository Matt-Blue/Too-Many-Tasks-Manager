<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;//to get information on current user
use Illuminate\Support\Facades\DB;//to perform database queries
use Illuminate\Http\Request;//HTTP requests
use App\Http\Requests\ContactFormRequest;//used for creating tasks
use Illuminate\Support\Facades\Redirect;//easy redirects
use Illuminate\Support\Facades\URL;//easy url manipulation

class SettingsController extends Controller
{
    // Check for settings and assign default if missing
    public function settingsCheck(){
        $user_id = Auth::id();//gets user id
        $s = \App\Setting::find($user_id);
        if($s === NULL){// Create settings
            // Default Sort
            $sorting = 'priority';

            // Coloring scheme
            $coloring = 'row';

            // Which columns to color
            $p_col = 1;
            $n_col = 1;
            $d_col = 1;
            $t_col = 1;

            // Color Choices
            $five = "#ff6698";//red
            $four ="#ffb366";//orange
            $three = "#ffff66";//yellow
            $two = "#98ff66";//green 
            $one = "#6698ff";//blue

            // Create Settings Array
            $settings = array(
                "sorting"=>$sorting, 
                "coloring"=>$coloring, 
                "p_col"=>$p_col, 
                "n_col"=>$n_col, 
                "d_col"=>$d_col,
                "t_col"=>$t_col,
                "five"=>$five,
                "four"=>$four,
                "three"=>$three,
                "two"=>$two,
                "one"=>$one
            );

            //go to form view with compacted associative array
            return view('settings')->with('settings', $settings);
        }
        else{
            //go to form view with compacted associative array
            $to_unserialize = $s->settings;
            $settings = unserialize($to_unserialize);
            // Color by cell or row
            $coloring = $settings['coloring'];
            // Default sort
            $sorting = $settings['sorting'];
            // Which columns should be colored
            $p_col = $settings['p_col'];
            $n_col = $settings['n_col'];
            $d_col = $settings['d_col'];
            $t_col = $settings['t_col'];
            // Color choosing
            $five = $settings['five'];
            $four = $settings['four'];
            $three = $settings['three'];
            $two = $settings['two'];
            $one = $settings['one'];
            // Create Settings Array
            $settings = array(
                "sorting"=>$sorting, 
                "coloring"=>$coloring, 
                "p_col"=>$p_col, 
                "n_col"=>$n_col, 
                "d_col"=>$d_col,
                "t_col"=>$t_col,
                "five"=>$five,
                "four"=>$four,
                "three"=>$three,
                "two"=>$two,
                "one"=>$one
            );
            //go to form view with compacted associative array
            return view('settings')->with('settings', $settings);
        }
    }

    // Update settings
    public function settings(Request $request){
        $user_id = Auth::id();//gets user id
        $set = \App\Setting::find($user_id);

        // Create settings array
        // Color by cell or row
        $coloring = $request->get('coloring');
        // Default Sorting
        $sorting = $request->get('sorting');
        // Which Columns should be colored
        $p_col = $request->get('p_col');
        $n_col = $request->get('n_col');
        $d_col = $request->get('d_col');
        $t_col = $request->get('t_col');
        // Color Choosing
        $five = $request->get('five');
        $four = $request->get('four');
        $three = $request->get('three');
        $two = $request->get('two');
        $one = $request->get('one');
        // Create and Serialize Array
        $settings = array(
            "sorting"=>$sorting, 
            "coloring"=>$coloring, 
            "p_col"=>$p_col, 
            "n_col"=>$n_col, 
            "d_col"=>$d_col,
            "t_col"=>$t_col,
            "five"=>$five,
            "four"=>$four,
            "three"=>$three,
            "two"=>$two,
            "one"=>$one
        );
        $serialized = serialize($settings);

        // Create new settings
        if($set === NULL){
            $s = new \App\Setting;
            $s->id = $user_id;
            $s->settings = $serialized;
            $s->save();
            
            return redirect()->route('home');
        }
        // Update settings
        else{
            $s = \App\Setting::find($user_id);
            $s->id = $user_id;
            $s->settings = $serialized;
            $s->save();
            
            return redirect()->route('home');
        }
    }

    // Update settings
    public function resetSettings(){
        $user_id = Auth::id();//gets user id
        \App\Setting::destroy($user_id);
        return redirect()->back();
    }
}
