<?php $__env->startSection('content'); ?>

<?php 
    use Illuminate\Support\Facades\Route;

    $now = time();//sets current datetime 

    //autofill coloring scheme
    if($settings['coloring'] == 'row'){ $color = true; }
    else{ $color = false; }

    //autofill columns to be colored
    $p_col = $settings['p_col'];
    $n_col = $settings['n_col'];
    $d_col = $settings['d_col'];
    $t_col = $settings['t_col'];

    //autofill default sort
    if($settings['sorting'] == 'priority'){ $sort = 1; }
    elseif($settings['sorting'] == 'task_name'){ $sort = 2; }
    elseif($settings['sorting'] == 'date_time'){ $sort = 3; }
    else{ $sort = 1; }//default catch

    //autofill color choices
    $five = $settings['five'];
    $four = $settings['four'];
    $three = $settings['three'];
    $two = $settings['two'];
    $one = $settings['one'];

    $t = false;//temporary variable
?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-6 col-md-offset-3">

            <!-- SETTINGS FORM -->
                <?php echo Form::open(['route' => 'settings']); ?>


            <!-- Color by either cell or row -->
                <br>
                    <?php echo Form::label('Color Choice', 'Color Choice'); ?>

                    <br>
                    <?php echo e(Form::color('five', $five)); ?> Most Important
                    <br>
                    <?php echo e(Form::color('four', $four)); ?> Very Important
                    <br>
                    <?php echo e(Form::color('three', $three)); ?> Moderately Important
                    <br>
                    <?php echo e(Form::color('two', $two)); ?> Less Important
                    <br>
                    <?php echo e(Form::color('one', $one)); ?> Least Important
                    <br>
                <br>
            
            <!-- Color by either cell or row -->
                <br>
                    <?php echo Form::label('coloring', 'How the Cells are Colored'); ?>

                    <br>
                    <?php echo e(Form::radio('coloring', 'row', $color)); ?> By Row
                    <br>
                    <?php echo e(Form::radio('coloring', 'cell', !$color)); ?> By Cell
                <br>

            <!-- Which columns should be colored -->
                <br>
                    <?php echo Form::label('columns', 'Which Columns Should be Color Coded'); ?>

                    <br>
                    <?php echo e(Form::checkbox('p_col', 1, $p_col)); ?> Priority
                    <br>
                    <?php echo e(Form::checkbox('n_col', 1, $n_col)); ?> Task Name
                    <br>
                    <?php echo e(Form::checkbox('d_col', 1, $d_col)); ?> Date
                    <br>
                    <?php echo e(Form::checkbox('t_col', 1, $t_col)); ?> Time
                <br>

            <!-- Default sorting -->
                <br>
                    <?php echo Form::label('sorting', 'Default Sorting Scheme'); ?><br>
                    <?php if($sort == 1){ $t = true; } ?>
                    <?php echo e(Form::radio('sorting', 'priority', $t)); ?> By Priority
                    <br>
                    <?php $t = false; ?>
                    <?php if($sort == 2){ $t = true; } ?>
                    <?php echo e(Form::radio('sorting', 'task_name', $t)); ?> By Name
                    <br>
                    <?php $t = false; ?>
                    <?php if($sort == 3){ $t = true; } ?>
                    <?php echo e(Form::radio('sorting', 'date_time', $t)); ?> By Date
                    <?php $t = false; ?>
            
                <br><br>
                <?php echo e(Form::checkbox('p_col', 1, $p_col)); ?> Email Notifications
                <br><br><br>

            <?php echo Form::submit('Update', ['class' => 'btn btn-primary pull-right']); ?>

            <button  type="button" class="btn btn-danger pull-left" data-toggle="modal" data-target="#reset_settings_modal" style="margin-bottom: 1em;">Reset to Default</button>
            
            <?php echo Form::close(); ?>


        </div><br><br><br><br>

        <!--                      -->
        <!-- RESET SETTINGS CHECK -->
        <!--                      -->
        <div class="modal fade" id="reset_settings_modal"  tabindex="-1" role="dialog" aria-labelledby="reset_settings_modal_label">
            <div class="modal-dialog" role="document">
                <div class="modal-content">

                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="create_task_label">Reset Settings</h4>
                </div>

                    <div class="modal-body">
                        Are you sure you want to reset your settings to the default?
                    </div>
                    <div class="modal-footer">
                        <a href="<?php echo e(route('reset_settings')); ?>">
                            <button  type="button" class="btn btn-danger pull-right">Reset to Default</button>
                        </a>
                    </div><!--necessary for the back of the modal to not be cut off at the bottom-->
                </div>
            </div>
        </div>
        <div class="row"></div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>