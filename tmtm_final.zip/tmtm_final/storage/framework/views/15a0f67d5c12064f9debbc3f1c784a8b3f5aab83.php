<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>TMTM</title>
	<link rel="icon" 
      type="image/png" 
      href="img/logo-alt.png">

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700%7CVarela+Round" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />

	<!-- Owl Carousel -->
	<link type="text/css" rel="stylesheet" href="css/owl.carousel.css" />
	<link type="text/css" rel="stylesheet" href="css/owl.theme.default.css" />

	<!-- Magnific Popup -->
	<link type="text/css" rel="stylesheet" href="css/magnific-popup.css" />

	<!-- Font Awesome Icon -->
	<link rel="stylesheet" href="css/font-awesome.min.css">

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="css/style.css" />

</head>

<body>
	<!-- Header -->
	<header id="home">
		<!-- Background Image -->
		<div class="bg-img" style="background-image: url('./img/index.jpg');">
			<div class="overlay"></div>
		</div>
		<!-- /Background Image -->

		<!-- Nav -->
		<nav id="nav" class="navbar nav-transparent">
			<div class="container">

				<div class="navbar-header">
					<!-- Logo -->
					<div class="navbar-brand">
						<a href="<?php echo e(route('index')); ?>">
							<img class="logo" src="img/logo.png" alt="logo">
							<img class="logo-alt" src="img/logo-alt.png" alt="logo">
						</a>
					</div>
					<!-- /Logo -->

					<!-- Collapse nav button -->
					<div class="nav-collapse">
						<span></span>
					</div>
					<!-- /Collapse nav button -->
				</div>

				<!--  Main navigation  -->
				<ul class="main-nav nav navbar-nav navbar-right">
					<li><a href="#home">Home</a></li>
					<li><a href="#about">About</a></li>
					<li><a href="#registration">Sign Up / Login</a></li>
					<li><a href="#team">Team</a></li>
					<li><a href="#contact">Contact</a></li>
				</ul>
				<!-- /Main navigation -->

			</div>
		</nav>
		<!-- /Nav -->

		<!-- home wrapper -->
		<div class="home-wrapper">
			<div class="container">
				<div class="row">

					<!-- home content -->
					<div class="col-md-10 col-md-offset-1">
						<div class="home-content">
							<h1 class="white-text">Too Many Tasks Manager</h1>
							<h3 class="white-text">Organize by Priority</h3>
							<?php if(Auth::check()): ?>
								<a href="<?php echo e(url('/home')); ?>" id="black"><button class="white-btn"><?php echo e(Auth::user()->name); ?>'s Dashboard</button></a>
							<?php else: ?>
								<a href="#registration"><button class="white-btn">Sign Up / Login</button></a>
							<?php endif; ?>
							<a class="blue-btn" href="#about">Learn More</a>
						</div>
					</div>
					<!-- /home content -->

				</div>
			</div>
		</div>
		<!-- /home wrapper -->

	</header>
	<!-- /Header -->
	
	<!-- About -->
	<div id="about" class="section md-padding">

		<!-- Container -->
		<div class="container">

			<!-- Row -->
			<div class="row">

				<!-- Section header -->
				<div class="section-header text-center">
					<h2 class="title">About TMTM</h2>
				</div>
				<!-- /Section header -->

				<!-- about -->
				<div class="col-md-4">
					<div class="about">
						<i class="fa fa-cogs"></i>
						<h3>Fully Customizible</h3>
						<p style="color: #868F9B;">
							Users have full customization over sorting and color coding of all tasks 
							and flexibility in creating tasks.
						</p>
						<!-- <a href="#">Read more</a> -->
					</div>
				</div>
				<!-- /about -->

				<!-- about -->
				<div class="col-md-4">
					<div class="about">
						<i class="fa fa-magic"></i>
						<h3>Awesome Features</h3>
						<p style="color: #868F9B;">
							A simple interface allows users to effortlessly work 
							while customization makes it an efficient day-to-day planner.
						</p>
						<!-- <a href="#">Read more</a> -->
					</div>
				</div>
				<!-- /about -->

				<!-- about -->
				<div class="col-md-4">
					<div class="about">
						<i class="fa fa-mobile"></i>
						<h3>Fully Responsive</h3>
						<p style="color: #868F9B;">TMTM works on mobile and desktop, making it the perfect tool for on-the-go task management.</p>
						<!-- <a href="#">Read more</a> -->
					</div>
				</div>
				<!-- /about -->

			</div>
			<!-- /Row -->

		</div>
		<!-- /Container -->

	</div>
	<!-- /About -->

	<!-- registration -->
	<div id="registration" class="section sm-padding">

		<!-- Background Image -->
		<div class="bg-img" style="background-image: url('./img/rain.jpg');">
			<div class="overlay"></div>
		</div>
		<!-- /Background Image -->

		<!-- Container -->
		<div class="container">

			<!-- Row -->
			<div class="row">
				<div class="col-md-6">
					<div class="section-header text-center">
						<br><h6 class="title">Create An Account</h6>
					</div>
					<!-- register -->
					<div class="container" id="registration">
						<div class="row">
							<div class="col-md-6">
								<div>
									<div class="panel-body">
										<form class="form-horizontal" method="POST" action="<?php echo e(route('register')); ?>">
											<?php echo e(csrf_field()); ?>


											<div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
												<label for="name" class="col-md-4 control-label" style="color: white;">Name</label>

												<div class="col-md-6">
													<input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

													<?php if($errors->has('name')): ?>
														<span class="help-block">
															<strong><?php echo e($errors->first('name')); ?></strong>
														</span>
													<?php endif; ?>
												</div>
											</div>

											<div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
												<label for="email" class="col-md-4 control-label" style="color: white;">E-Mail Address</label>

												<div class="col-md-6">
													<input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>

													<?php if($errors->has('email')): ?>
														<span class="help-block">
															<strong><?php echo e($errors->first('email')); ?></strong>
														</span>
													<?php endif; ?>
												</div>
											</div>

											<div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
												<label for="password" class="col-md-4 control-label" style="color: white;">Password</label>

												<div class="col-md-6">
													<input id="password" type="password" class="form-control" name="password" required>

													<?php if($errors->has('password')): ?>
														<span class="help-block">
															<strong><?php echo e($errors->first('password')); ?></strong>
														</span>
													<?php endif; ?>
												</div>
											</div>

											<div class="form-group">
												<label for="password-confirm" class="col-md-4 control-label" style="color: white;">Confirm Password</label>

												<div class="col-md-6">
													<input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
												</div>
											</div>

											<div class="form-group">
												<div class="col-md-6 col-md-offset-4">
													<button type="submit" class="btn btn-primary">
														Register
													</button>
												</div>
											</div>
										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- login -->
				<div class="col-md-6">
				<div class="section-header text-center">
					<br><h6 class="title">Login</h6>
				</div>

				<div class="container" id="registration">
					<div class="row">
						<div class="col-md-6">
							<div>
								<div>
									<form class="form-horizontal" method="POST" action="<?php echo e(route('login')); ?>">
										<?php echo e(csrf_field()); ?>


										<div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
											<label for="email" class="col-md-4 control-label" style="color: white;">E-Mail Address</label>

											<div class="col-md-6">
												<input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

												<?php if($errors->has('email')): ?>
													<span class="help-block">
														<strong><?php echo e($errors->first('email')); ?></strong>
													</span>
												<?php endif; ?>
											</div>
										</div>

										<div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
											<label for="password" class="col-md-4 control-label" style="color: white;">Password</label>

											<div class="col-md-6">
												<input id="password" type="password" class="form-control" name="password" required>

												<?php if($errors->has('password')): ?>
													<span class="help-block">
														<strong><?php echo e($errors->first('password')); ?></strong>
													</span>
												<?php endif; ?>
											</div>
										</div>

										<div class="form-group">
											<div class="col-md-6 col-md-offset-4">
												<div class="checkbox">
													<label style="color: white;">
														<input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
													</label>
												</div>
											</div>
										</div>

										<div class="form-group">
											<div class="col-md-8 col-md-offset-4">
												<button type="submit" class="btn btn-primary">
													Login
												</button>

												<a class="btn btn-link" href="<?php echo e(route('password.request')); ?>" style="color: white;">
													Forgot Your Password?
												</a>
											</div>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			</div>
		<!-- /Row -->
		</div>
		<!-- /Container -->

	</div>
	<!-- /Numbers -->

	<!-- Team -->
	<div id="team" class="section md-padding">

		<!-- Container -->
		<div class="container">

			<!-- Row -->
			<div class="row">

				<!-- Section header -->
				<div class="section-header text-center">
					<h2 class="title">Our Team</h2>
				</div>
				<!-- /Section header -->

				<!-- team -->
				<div class="col-sm-4">
					<div class="team">
						<div class="team-img">
							<img class="img-responsive" src="./img/matthew.jpg" alt="">
							<div class="overlay">
								<div class="info">
									<h3> Third year Computer Science major with a minor in Spanish at the University of Florida</h3>
								</div>
								<div class="team-social">
									<a href="https://www.linkedin.com/in/matthew-bluestein-61526a10b/" target="_blank"><i class="fa fa-linkedin"></i></a>
									<a href="https://github.com/Matt-Blue" target="_blank"><i class="fa fa-github"></i></a>
								</div>
							</div>
						</div>
						<div class="team-content">
							<h3>Matthew Bluestein</h3>
							<span>Back End</span>
						</div>
					</div>
				</div>
				<!-- /team -->

				<!-- team -->
				<div class="col-sm-4">
					<div class="team">
						<div class="team-img">
							<img class="img-responsive" src="./img/ayla.jpg" alt="">
							<div class="overlay">
								<div class="info">
									<h3>Third year Computer Engineering student at The University of Florida</h3>
								</div>
								<div class="team-social">
									<a href="https://www.linkedin.com/in/lademirpolat/" target="_blank"><i class="fa fa-linkedin"></i></a>
									<a href="https://github.com/lynseydem" target="_blank"><i class="fa fa-github"></i></a>
								</div>
							</div>
						</div>
						<div class="team-content">
							<h3>Lynsey Demirpolat</h3>
							<span>Front End</span>
						</div>
					</div>
				</div>
				<!-- /team -->

				<!-- team -->
				<!-- <div class="center-card"> -->
				<div class="col-sm-4">
					<div class="team">
						<div class="team-img">
							<img class="img-responsive" src="./img/ximena.jpg" alt="">
							<div class="overlay">
								<div class="info">
									<h3> Fourth Year Digital Arts and Sciences student at the University of Florida</h3>
								</div>
								<div class="team-social">
									<a href="https://www.linkedin.com/in/ximenajaramillo/" target="_blank"><i class="fa fa-linkedin"></i></a>
									<a href="https://github.com/xipaja" target="_blank"><i class="fa fa-github"></i></a>
								</div>
							</div>
						</div>
						<div class="team-content">
							<h3>Ximena Jaramillo</h3>
							<span>Front End</span>
						</div>
					</div>
				</div>
				<!-- /team -->

				<!-- team -->
				<div class="col-sm-4">
					<div class="team">
						<div class="team-img">
							<img class="img-responsive" src="./img/michael.jpg" alt="">
							<div class="overlay">
								<div class="info">
									<h3> Third Year Computer Science student at the University of Florida</h3>
								</div>
								<div class="team-social">
									<a href="https://www.linkedin.com/in/michael-pereira-499456142/" target="_blank"><i class="fa fa-linkedin"></i></a>
									<a href="https://github.com/migrepereira" target="_blank"><i class="fa fa-github"></i></a>
								</div>
							</div>
						</div>
						<div class="team-content">
							<h3>Michael Pereira</h3>
							<span>Back End</span>
						</div>
					</div>
				</div>
				<!-- /team -->

				<!-- team -->
				<div class="col-sm-4">
					<div class="team">
						<div class="team-img">
							<img class="img-responsive" src="./img/audrey.jpg" alt="">
							<div class="overlay">
								<div class="info">
									<h3>Third year Computer Engineering student at The University of Florida</h3>
								</div>
								<div class="team-social">
									<a href="https://www.linkedin.com/in/audreyservilio/" target="_blank"><i class="fa fa-linkedin"></i></a>
									<a href="https://github.com/audreyservilio" target="_blank"><i class="fa fa-github"></i></a>
								</div>
							</div>
						</div>
						<div class="team-content">
							<h3>Audrey Servilio</h3>
							<span>Front End</span>
						</div>
					</div>
				</div>
			<!-- </div> -->
				<!-- /team -->

			</div>
			<!-- /Row -->

		</div>
		<!-- /Container -->

	</div>
	<!-- /Team -->

	<!-- Contact -->
	<div id="contact" class="section md-padding bg-grey">

		<!-- Container -->
		<div class="container">

			<!-- Row -->
			<div class="row">

				<!-- Section-header -->
				<div class="section-header text-center">
					<h2 class="title">Get in touch</h2>
				</div>
				<!-- /Section-header -->

				<!-- contact -->
				<div class="col-sm-4">
					<div class="contact">
						<i class="fa fa-phone"></i>
						<h3>Phone</h3>
						<p>1 (800) Too Many</p>
					</div>
				</div>
				<!-- /contact -->

				<!-- contact -->
				<div class="col-sm-4">
					<div class="contact">
						<i class="fa fa-envelope"></i>
						<h3>Email</h3>
						<p>Support@TooManyTasksManager.com</p>
					</div>
				</div>
				<!-- /contact -->

				<!-- contact -->
				<div class="col-sm-4">
					<div class="contact">
						<i class="fa fa-map-marker"></i>
						<h3>Address</h3>
						<p>1739 Tasks Drive</p>
					</div>
				</div>
				<!-- /contact -->

				<!-- contact form -->
				<!-- <div class="col-md-8 col-md-offset-2">
					<form class="contact-form">
						<input type="text" class="input" placeholder="Name">
						<input type="email" class="input" placeholder="Email">
						<input type="text" class="input" placeholder="Subject">
						<textarea class="input" placeholder="Message"></textarea>
						<button class="main-btn">Send message</button>
					</form>
				</div> -->
				<!-- /contact form -->

			</div>
			<!-- /Row -->

		</div>
		<!-- /Container -->

	</div>
	<!-- /Contact -->


	<!-- Footer -->
	<footer id="footer" class="sm-padding bg-dark" >

		<!-- Container -->
		<div class="container">

			<!-- Row -->
			<div class="row">

				<div class="col-md-12">

					<!-- footer logo -->
					<div class="footer-logo">
						<a href="<?php echo e(route('index')); ?>"><img src="img/logo-alt.png" alt="logo"></a>
					</div>
					<!-- /footer logo -->

					<!-- footer follow -->
					<!-- <ul class="footer-follow">
						<li><a href="#"><i class="fa fa-facebook"></i></a></li>
						<li><a href="#"><i class="fa fa-twitter"></i></a></li>
						<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
						<li><a href="#"><i class="fa fa-instagram"></i></a></li>
						<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
						<li><a href="#"><i class="fa fa-youtube"></i></a></li>
					</ul> -->
					<!-- /footer follow -->

					<!-- footer copyright -->
					<div class="footer-copyright" style="color: white;">
						<p>Copyright © 2018. All Rights Reserved. <br>Too Many Tasks Manager</p>
					</div>
					<!-- /footer copyright -->

				</div>

			</div>
			<!-- /Row -->

		</div>
		<!-- /Container -->

	</footer>
	<!-- /Footer -->

	<!-- Back to top -->
	<div id="back-to-top"></div>
	<!-- /Back to top -->

	<!-- Preloader -->
	<div id="preloader">
		<div class="preloader">
			<span></span>
			<span></span>
			<span></span>
			<span></span>
		</div>
	</div>
	<!-- /Preloader -->

	<!-- jQuery Plugins -->
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/owl.carousel.min.js"></script>
	<script type="text/javascript" src="js/jquery.magnific-popup.js"></script>
	<script type="text/javascript" src="js/main.js"></script>

</body>

</html>
