<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>TMTM</title>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

    <!--Bootstrap-->
<!--        <link rel="stylesheet" type="text/css" href="http://netdna.bootstrapcdn.com/twitter-bootstrap/2.3.0/css/bootstrap-combined.min.css">-->

    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>

<!--
    <script type='text/javascript' src='http://code.jquery.com/jquery-1.10.1.js'></script>
    <script type='text/javascript' src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
-->

    
       <!-- Pop Legend -->
    <style>
        
    /* Popup container - can be anything you want */
    #pop {
        position: relative;
        display: inline-block;
        cursor: pointer;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
    }

    /* The actual popup */
    #pop .popuptext {
        visibility: hidden;
/*        width: 160px;*/
/*        background-color: #555 !important;*/
/*        color: #555;*/
        text-align: center;
/*        border-radius: 6px;*/
/*        padding: 8px 0;*/
/*        position: absolute;*/
/*        z-index: 1;*/
/*        bottom: 125%;*/
/*        left: 50%;*/
/*        margin-left: -80px;*/
/*        overflow: visible;*/
    }
        
        
    /* Popup arrow */
    .popup .popuptext::after {
        content: "";
/*        position: absolute;*/
/*        top: 100%;*/
/*        left: 50%;*/
/*        margin-left: -5px;*/
/*        border-width: 5px;*/
        border-style: solid;
        border-color: #666 transparent transparent transparent;
    }

    /* Toggle this class - hide and show the popup */
    .popup .show {
        visibility: visible;
        -webkit-animation: fadeIn 1s;
        animation: fadeIn 1s;
    }

        .navbar-default{
            height: 50px !important;
        }
    /* Add animation (fade in the popup) */
    @-webkit-keyframes fadeIn {
        from {opacity: 0;} 
        to {opacity: 1;}
    }

    @keyframes  fadeIn {
        from {opacity: 0;}
        to {opacity:1 ;}
    }
        
        .header {
            height: 100px !important;
        }
        
        body{
            background-image: url("./back.jpg") !important;
        }
    </style>
    <!-- End of Popup Legend -->

</head>
<body>
    <div id="app">
        <nav class=" navbar-default ">
            <div class="container ">
                <div class="navbar-header" >

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        TMTM
                    </a>
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        &nbsp;
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        <?php if(Auth::guest()): ?>
                            <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                            <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                        <?php else: ?>
                            <li><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                            <li><a href="<?php echo e(route('settingsCheck')); ?>">Settings</a></li>
                            <li><a href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                            document.getElementById('logout-form').submit();">
                                Logout
                            </a></li>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo e(csrf_field()); ?>

                            </form>
                        <div class="row">
                            <div class="col-md-12 text-bottom">
                                <span class="glyphicon glyphicon-info-sign" data-toggle="popover" data-trigger="hover" data-placement="bottom" ></span>
                                <div id="pop">
                                    <div class="popuptext">
                                        <div style="color: #F87171;">Most Important</div>
                                        <div style="color: #FCA350;">Very Important</div>
                                        <div style="color: #F6EA59;">Moderately Important</div>
                                        <div style="color: #59D588;">Less Important</div>
                                        <div style="color: #69C1F3;">Least Important</div>
                                        <div style="color: white;">Not Important</div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <!--Insert content below-->
        <?php echo $__env->yieldContent('content'); ?>
<!--
<div class="bg-img" style="background-image: url('./img/octo.jpg');">
			<div class="overlay"></div>
		</div>
    </div>
-->
         <footer id="footer" class="sm-padding bg-dark">

		<!-- Container -->
		<div class="container">

			<!-- Row -->
			<div class="row">

				<div class="col-md-12">

					<!-- footer logo -->
					<div class="footer-logo">
						<img src="logo-alt.png" alt="logo">
					</div>
					<!-- /footer logo -->

					<!-- footer copyright -->
					<div class="footer-copyright">
						<p>Too Many Tasks Manager</a></p>
					</div>
					<!-- /footer copyright -->

				</div>

			</div>
			<!-- /Row -->

		</div>
		<!-- /Container -->

	</footer>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>
