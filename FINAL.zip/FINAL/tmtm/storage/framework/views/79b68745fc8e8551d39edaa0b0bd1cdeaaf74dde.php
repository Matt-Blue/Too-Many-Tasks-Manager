<?php $__env->startSection('content'); ?>

<?php 
    use Illuminate\Support\Facades\Route;

    $now = time();//sets current datetime 

    //autofill coloring scheme
    if($settings['coloring'] == 'row'){ $color = true; }
    else{ $color = false; }

    //autofill columns to be colored
    $p_col = $settings['p_col'];
    $n_col = $settings['n_col'];
    $d_col = $settings['d_col'];

    //autofill default sort
    if($settings['sorting'] == 'priority'){ $sort = 1; }
    elseif($settings['sorting'] == 'task_name'){ $sort = 2; }
    elseif($settings['sorting'] == 'date_time'){ $sort = 3; }
    else{ $sort = 1; }//default catch
    $t = false;//temporary variable
?>

<div class="col-md-6 col-md-offset-3">

    <!-- SETTINGS FORM -->
        <?php echo Form::open(['route' => 'settings']); ?>

    <!-- Color by either cell or row -->
        <br>
            <?php echo Form::label('coloring', 'How the Cells are Colored'); ?>

            <br>
            <?php echo e(Form::radio('coloring', 'row', $color)); ?> By Row
            <br>
            <?php echo e(Form::radio('coloring', 'cell', !$color)); ?> By Cell
        <br>
    <!-- Which columns should be colored -->
        <br>
            <?php echo Form::label('columns', 'Which Columns Should be Color Coded'); ?>

            <br>
            <?php echo e(Form::checkbox('p_col', 1, $p_col)); ?> Priority
            <br>
            <?php echo e(Form::checkbox('n_col', 1, $n_col)); ?> Task Name
            <br>
            <?php echo e(Form::checkbox('d_col', 1, $d_col)); ?> Date and Time
        <br>
    <!-- Default sorting -->
        <br>
            <?php echo Form::label('sorting', 'Default Sorting Scheme'); ?><br>
            <?php if($sort == 1){ $t = true; } ?>
            <?php echo e(Form::radio('sorting', 'priority', $t)); ?> By Priority
            <br>
            <?php $t = false; ?>
            <?php if($sort == 2){ $t = true; } ?>
            <?php echo e(Form::radio('sorting', 'task_name', $t)); ?> By Name
            <br>
            <?php $t = false; ?>
            <?php if($sort == 3){ $t = true; } ?>
            <?php echo e(Form::radio('sorting', 'date_time', $t)); ?> By Date
            <?php $t = false; ?>
        <br>

    <?php echo Form::submit('Update', ['class' => 'btn btn-primary pull-right']); ?>


    <?php echo Form::close(); ?>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>