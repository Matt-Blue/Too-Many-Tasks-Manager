@extends('layouts.app')

@section('content')
    @if (Route::has('login'))
        <div class="top-right links">
            
        </div>
    @endif

    <div class="content">
      
            <h1>Too Many Tasks Manager</h1><br>
            @if (Auth::check())
                <button class="btn btn-default" onclick="location.href= '/home';" id="black">{{ Auth::user()->name }}'s Dashboard</button>
            @endif        
      
    </div>
@endsection
