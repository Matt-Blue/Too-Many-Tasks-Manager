

<?php $__env->startSection('content'); ?>

<?php 
    use Illuminate\Support\Facades\Route;
    use App\Helpers;
    
    $now = time();
     
    ///////////////////////////////////
    /////////GENERAL SETTINGS//////////
    ///////////////////////////////////

    $user_id = Auth::id();
    $s = \App\Setting::find($user_id);
    if($s === NULL){// Default settings
        // Default Sort
        $sorting = 'priority';
        // Coloring scheme
        $coloring = 'row';
        // Which columns to color
        $p_col = 1;
        $n_col = 1;
        $d_col = 1;
        $t_col = 1;
        // Color Choices
        $five = "#F87171";//red
        $four ="#FCA350";//orange
        $three = "#F6EA59";//yellow
        $two = "#59D588";//green 
        $one = "#69C1F3";//blue
    }
    else{// Custom settings
        $to_unserialize = $s->settings;
        $settings = unserialize($to_unserialize);// unserialize associative array
        // Color by cell or row
        $coloring = $settings['coloring'];
        // Default sort
        $sorting = $settings['sorting'];
        // Which columns should be colored
        $p_col = $settings['p_col'];
        $n_col = $settings['n_col'];
        $d_col = $settings['d_col'];
        $t_col = $settings['t_col'];
        // Color choosing
        $five = $settings['five'];
        $four = $settings['four'];
        $three = $settings['three'];
        $two = $settings['two'];
        $one = $settings['one'];
    }

    ////////////////////////////////
    ////////////HEADINGS////////////
    ////////////////////////////////
?>

<div  class="container" style="padding-top: 20px;">
    <div   style="background-color: #F4F4F4;">
            <button class="btn btn-default" data-toggle="modal" href="#create_task_modal" style="top: 100px !important; left:-140px !important">New Task</button>
        <div class="popover pull-right" data-placement="right !important;" data-toggle="popover" onmouseover="Popup()"  >Legend
            <span class="popuptext" id="myPopup" >
                <div style="color: <?php echo e($five); ?>;">Most Important</div>
                <div style="color: <?php echo e($four); ?>;">Very Important</div>
                <div style="color: <?php echo e($three); ?>;">Moderately Important</div>
                <div style="color: <?php echo e($two); ?>;">Less Important</div>
                <div style="color: <?php echo e($one); ?>;">Least Important</div>
                <div style="color: white;">Not Important</div>
            </span>
        </div>
        </div>
    
    <br>
    <div class="row">
        
        <div class="col-md-12">
            <?php if(session('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </div>
            
            <?php endif; ?>
            <!-- Display Tasks based on user_id -->
            
            <table style="width:100%">
                <tr>
                    
                    <div class="col-xs-1">
                        <th>
                            <a href="<?php echo e(route('priority')); ?>" class="pull-left">
                                <span class="glyphicon glyphicon-arrow-down" style="color:black; font-size: 0.75em;" id="pad"></span>
                            </a>
                            <div class="dbpad" style="background-color: white;">Priority</div>
                        </th>
                    </div>
                    <div class="col-xs-5">
                        <th>
                            <a href="<?php echo e(route('task_name')); ?>" class="pull-left">
                                <span class="glyphicon glyphicon-arrow-down" style="color:black; font-size: 0.75em;" id="pad"></span>
                            </a>
                            <div class="dbpad" style="background-color: white;">Task Name</div>
                        </th> 
                    </div>
                    <div class="col-xs-3">
                        <th>
                            <a href="<?php echo e(route('date_time')); ?>" class="pull-left">
                                <span class="glyphicon glyphicon-arrow-down" style="color:black; font-size: 0.75em;" id="pad"></span>
                            </a>
                            <div class="dbpad" style="background-color: white;">Due Date</div>
                        </th>
                    </div>
                    <div class="col-md-2">
                        <th id="dbpad" style="background-color: white;">
                            Time
                        </th>
                    </div>
                    <div class="col-xs-1"> <th><span><div class="dbpad" style="background-color: white; text-align: center;">Done</div></span></th>
                    </div>
                </tr>

                <!-- //////////////////////////////
                ///////PREFERENCES PER TASK////////
                /////////////////////////////// -->

                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php 
                        // Priority Color
                        $priority_color = $task->priority;

                        // Date Color (Based on difference from current date)
                        $target = strtotime($task->date);
                        $diff = $target - $now;
                        if( $task->date == NULL ){ $date_color = 0; }//no color
                        elseif ( $diff < 0 ) { $date_color = 5; }//red (under 12 hours or 43200 seconds)
                        elseif ( $diff < 43200 ) { $date_color = 4; }//orange (under a day and half or 129600 seconds)
                        elseif ( $diff < 129600 ) { $date_color = 3; }//yellow (under 3 days or 259200 seconds)
                        elseif ( $diff < 259200 ) { $date_color = 2; }//green (under 5 days or 432000 seconds)
                        elseif ( $diff < 432000 ) { $date_color = 1; }//blue (under 1 week or 604800 seconds)
                        else{ $date_color = 0; }//no color

                        // Name Color (average of date and priority color)
                        $name_color = ceil(($date_color + $priority_color) / 2);
                        // Special Casese where Name Color is max priority
                        if($date_color == 5){ 
                            if($priority_color != 0){ $name_color = 5; }
                        }
                        if($priority_color == 5){
                            if($date_color != 0){ $name_color = 5; }
                        }

                        //Format Date
                        $raw_date = $task->date;
                        $to_date = strtotime($raw_date);
                        $date = date('n/d/Y', $to_date);

                        //Format Time
                        $raw_time = $task->time;
                        $to_time = strtotime($raw_time);
                        $time = date("g:i A", $to_time);
                    ?>

                    <!-- //////////////////////////////
                    ////////////DASHBOARD//////////////
                    /////////////////////////////// -->

                    <tr>
                        

                        <!-- (-) PRIORITY (+) -->
                        <div class="col-xs-1">
                            <td
                                <?php
                                    if($p_col){
                                        if($coloring == 'row'){
                                            //set the color of the priority cell based on name color value
                                            if($name_color == 5){ echo('bgcolor="' . $five . '"'); }//red
                                            if($name_color == 4){ echo('bgcolor="' . $four . '"'); }//orange
                                            if($name_color == 3){ echo('bgcolor="' . $three . '"'); }//yellow
                                            if($name_color == 2){ echo('bgcolor="' . $two . '"'); }//green 
                                            if($name_color == 1){ echo('bgcolor="' . $one . '"'); }//blue 
                                            //else no color
                                        }elseif($coloring == 'cell'){
                                            //set the color of the priority cell based on priority color value
                                            if($priority_color == 5){ echo('bgcolor="' . $five . '"'); }//red
                                            if($priority_color == 4){ echo('bgcolor="' . $four . '"'); }//orange
                                            if($priority_color == 3){ echo('bgcolor="' . $three . '"'); }//yellow
                                            if($priority_color == 2){ echo('bgcolor="' . $two . '"'); }//green 
                                            if($priority_color == 1){ echo('bgcolor="' . $one . '"'); }//blue 
                                            //else no color
                                        }
                                    }
                                ?>
                            >
                                <center >

                                    <!-- DECREMENT -->
                                    <div class="pull-left" id="pad">
                                        <?php if ($priority_color > 0){ ?>
                                            <a href="<?php echo e(url('/priority_down/'.$task->id)); ?>"><span class="glyphicon glyphicon-minus" style="color:black; font-size: 0.75em;"></span></a>
                                        <?php }else{ ?>
                                            <span class="glyphicon glyphicon-asterisk" style="color:black; font-size: 0.75em;"></span>
                                        <?php } ?>
                                    </div>

                                    <?php echo e($task->priority); ?>


                                    <!-- INCREMENT -->
                                    <div class="pull-right" id="pad">
                                        <?php if ($priority_color < 5){ ?>
                                            <a href="<?php echo e(url('/priority_up/'.$task->id)); ?>"> <span class="glyphicon glyphicon-plus" style="color:black; font-size: 0.75em;"></span></a>
                                        <?php }else{ ?>
                                            <span class="glyphicon glyphicon-asterisk" style="color:black; font-size: 0.75em;"></span>
                                        <?php } ?>
                                    </div>

                                </center>
                            </td>
                        </div>

                        <!-- (-) TASK NAME -->
                        <div class="col-xs-5">
                            <td 
                                <?php
                                    // COLORING //
                                    if($n_col){
                                        if($name_color == 5){ echo('bgcolor="' . $five . '"'); }//red
                                        if($name_color == 4){ echo('bgcolor="' . $four . '"'); }//orange
                                        if($name_color == 3){ echo('bgcolor="' . $three . '"'); }//yellow
                                        if($name_color == 2){ echo('bgcolor="' . $two . '"'); }//green 
                                        if($name_color == 1){ echo('bgcolor="' . $one . '"'); }//blue 
                                        //else no color
                                    }
                                ?>
                            >
                            <!-- EDIT TASK BUTTON -->
                            <a href="<?php echo e(url('/edit_task/'.$task->id)); ?>"><span class="glyphicon glyphicon-pencil" style="color:black; font-size: 0.75em;" id="pad"></span></a>
                            <?php echo e($task->task_name); ?>

                            </td>
                        </div>

                        <!-- (-) DATE (+) -->
                        <div class="col-xs-3">
                            <td
                                <?php
                                    // COLORING //
                                    if($d_col){
                                        if($coloring == 'row'){
                                            if($name_color == 5){ echo('bgcolor="' . $five . '"'); }//red
                                            if($name_color == 4){ echo('bgcolor="' . $four . '"'); }//orange
                                            if($name_color == 3){ echo('bgcolor="' . $three . '"'); }//yellow
                                            if($name_color == 2){ echo('bgcolor="' . $two . '"'); }//green 
                                            if($name_color == 1){ echo('bgcolor="' . $one . '"'); }//blue 
                                            //else no color
                                        }elseif($coloring == 'cell'){
                                            if($date_color == 5){ echo('bgcolor="' . $five . '"'); }//red
                                            if($date_color == 4){ echo('bgcolor="' . $four . '"'); }//orange
                                            if($date_color == 3){ echo('bgcolor="' . $three . '"'); }//yellow
                                            if($date_color == 2){ echo('bgcolor="' . $two . '"'); }//green 
                                            if($date_color == 1){ echo('bgcolor="' . $one . '"'); }//blue 
                                            //else no color
                                        }
                                    }
                                ?>
                            >
                                <center >
                                    <!-- DECREMENT DATE -->
                                    <?php if ($task->date != NULL){ ?>
                                        <div class="pull-left" id="pad">
                                            <a href="<?php echo e(url('/date_down/'.$task->id)); ?>"><span class="glyphicon glyphicon-minus" style="color:black; font-size: 0.75em;"></span></a>
                                        </div>
                                    <?php } ?>

                                    <?php if($task->date != NULL): ?>
                                        <?php echo e($date); ?>

                                    <?php endif; ?>
                                    
                                    <!-- INCREMENT DATE -->
                                    <?php if ($task->date != NULL){ ?>
                                        <div class="pull-right" id="pad">
                                            <a href="<?php echo e(url('/date_up/'.$task->id)); ?>"> <span class="glyphicon glyphicon-plus" style="color:black; font-size: 0.75em;"></span></a>
                                        </div>
                                    <?php } ?>

                                </center>
                                
                            </td>
                        </div>
                        
                        <div class="col-xs-2">
                            <td
                                <?php 
                                    // COLORING //
                                    if($t_col){
                                        if($coloring == 'row'){
                                            if($name_color == 5){ echo('bgcolor="' . $five . '"'); }//red
                                            if($name_color == 4){ echo('bgcolor="' . $four . '"'); }//orange
                                            if($name_color == 3){ echo('bgcolor="' . $three . '"'); }//yellow
                                            if($name_color == 2){ echo('bgcolor="' . $two . '"'); }//green 
                                            if($name_color == 1){ echo('bgcolor="' . $one . '"'); }//blue 
                                            //else no color
                                        }elseif($coloring == 'cell'){
                                            if($date_color == 5){ echo('bgcolor="' . $five . '"'); }//red
                                            if($date_color == 4){ echo('bgcolor="' . $four . '"'); }//orange
                                            if($date_color == 3){ echo('bgcolor="' . $three . '"'); }//yellow
                                            if($date_color == 2){ echo('bgcolor="' . $two . '"'); }//green 
                                            if($date_color == 1){ echo('bgcolor="' . $one . '"'); }//blue 
                                            //else no color
                                        }
                                    }
                                ?>
                            >
                                <div id="dbpad" >
                                    <?php if($task->time != NULL): ?>
                                        <?php echo e($time); ?>

                                    <?php endif; ?>
                                </div>
                            </td>
                        </div>
                        <!-- (-) DELETE BUTTON -->
                        <div class="col-xs-1" >
                            <td style="background-color: #F4F4F4 !important; width: 75px !important;">
                                <?php if(session('delete_id') == $task->id){ ?>
                                    <center><a href="<?php echo e(url('/delete/'.$task->id)); ?>"><span class="glyphicon glyphicon-ok-circle " style="color:black; font-size: 0.75em;" id="pad"></span></a></center>
                                <?php }else{ ?>
                                    <center><a href="<?php echo e(url('/delete_check/'.$task->id)); ?>"><span class="glyphicon glyphicon-ok" style="color:black; font-size: 0.75em;" id="pad"></span></a></center>
                                <?php } ?>
                            </td>
                        </div>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
</div>

<!-- //////////////////////////////
/////////////LEGEND////////////////
/////////////////////////////// -->
<br>

<!-- Footer -->
	<footer id="footer2" class="sm-padding bg-dark" >

		<!-- Container -->
		<div class="container">

			<!-- Row -->
			<div class="row">

				<div class="col-md-12">

					<!-- footer logo -->
					<div class="footer-logo">
						<a href="<?php echo e(route('index')); ?>"><img src="img/logo-alt.png" alt="logo"></a>
					</div>
					<!-- /footer logo -->

					<!-- footer follow -->
					<!-- <ul class="footer-follow">
						<li><a href="#"><i class="fa fa-facebook"></i></a></li>
						<li><a href="#"><i class="fa fa-twitter"></i></a></li>
						<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
						<li><a href="#"><i class="fa fa-instagram"></i></a></li>
						<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
						<li><a href="#"><i class="fa fa-youtube"></i></a></li>
					</ul> -->
					<!-- /footer follow -->

					<!-- footer copyright -->
					<div class="footer-copyright" style="color: white;">
						<p>Copyright © 2018. All Rights Reserved. <br>Too Many Tasks Manager</p>
					</div>
					<!-- /footer copyright -->

				</div>

			</div>
			<!-- /Row -->

		</div>
		<!-- /Container -->

	</footer>
	<!-- /Footer -->
<!-- //////////////////////////////
//////////////MODAL////////////////
/////////////////////////////// -->

<?php echo $__env->make('modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;

<!-- MODAL SCRIPT -->
<?php if(!empty(Session::get('modal'))): ?>
<script>
$(function() {
    $('#modal').modal('show');
});
</script>
<?php endif; ?>

<!-- POPUP SCRIPT FOR LEGEND -->
<script>
    function Popup() {
        var popup = document.getElementById("myPopup");
        popup.classList.toggle("show");
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>