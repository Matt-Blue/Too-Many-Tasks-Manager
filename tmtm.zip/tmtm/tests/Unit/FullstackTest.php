<?php

namespace Tests\Unit;

use Tests\TestCase;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Foundation\Testing\DatabaseTransactions;

class FullstackTest extends TestCase
{
    use DatabaseMigrations;
    use DatabaseTransactions;

    /**
     * A functional database test example.
     *
     * @return void
     */
    public function testFrontEnd()
    {
        // GO TO LOGIN

        // GO TO SIGN UP

        // GO BETWEEN HOMEPAGE AND DASHBOARD WHEN LOGGED IN
    }
    public function testBackend()
    {
        // HTTP REQUESTS WORK
        $response = $this->get('/');
        $response->assertStatus(200);

        // $response = $this->action('GET', 'TaskController@create', ['user' => 1]);
    }
    public function testUserRegistration()
    {
        // CREATE USER
        
        // $user = factory(App\User::class)->create();

        // $this->actingAs($user)
        //      ->withSession(['foo' => 'bar'])
        //      ->visit('/')
        //      ->see('Hello, '.$user->name);
        
        //actually create user thru registration process
        //make sure it is in the database

        // LOGIN
        //test to make sure session is present

        // LOGOUT
        //test to make sure session is destroyed

        // DELETE
        //delete user in database
    }
    public function testTaskORM()
    {
        // CREATE TASK

        // READ TASK

        // EDIT TASK

        // DELETE TASK

        // INCREMENT AND DECREMENT PRIORITY

        // INCREMENT AND DECREMENT DATE

    }
}
